"""Created by nidhi.sultan, Accenture 2020"""
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize 
import json
import traceback
import re
import numpy as np 
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
# from datetime import datetime

import requests
from bs4 import BeautifulSoup


# import datefinder
# import dateutil.parser as dparser

options = Options()
options.headless = True
options.add_argument("--window-size=1920,1200")
# driver = webdriver.Chrome(options=options, executable_path=r'chromedriver')

"""LINUX"""
# from selenium.webdriver.chrome.options import Options
#
# chrome_options = Options()
# chrome_options.add_argument('--headless')
# chrome_options.add_argument('--no-sandbox')
# chrome_options.add_argument('--disable-dev-shm-usage')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver',chrome_options=chrome_options)


# file_path = "C:\\Users\\nidhi.sultan\\Documents\\AAIE LABS\\SEAN\\graphsage\\Tweet_final.txt"
file_path = "fake_scraped_2513.txt"

def sim(X,Y):
  
    X_list = word_tokenize(X)
    Y_list = word_tokenize(Y)

    # sw contains the list of stopwords
    sw = stopwords.words('english')
    l1 =[];l2 =[]

    # remove stop words from the string
    X_set = {w for w in X_list if not w in sw}
    Y_set = {w for w in Y_list if not w in sw}

    # form a set containing keywords of both strings
    rvector = X_set.union(Y_set)
    for w in rvector:
        if w in X_set: l1.append(1) # create a vector
        else: l1.append(0)
        if w in Y_set: l2.append(1)
        else: l2.append(0)
    c = 0
  
    # cosine formula
    for i in range(len(rvector)):
            c+= l1[i]*l2[i]
    cosine = c / float((sum(l1)*sum(l2))**0.5)
    # print(X,Y, cosine)
    # print("similarity: ", cosine)
    return cosine

def countX(lst, x): 
    count = 0
    for ele in lst: 
        if (ele == x): 
            count = count + 1
    return count 

from collections import OrderedDict

"""MAIN FUNCTION TO CONSTRUCT TEXT FILE"""
def process(file_path):
    file = open(file_path, 'r',encoding="utf8")
    text_list_1 = []
    tweet_id =[]
    for i in file:
        # print(type(i),i)
        # text = i.replace("-1\t ", '')
        text = i.split('||')
        # print(text)
        # text = i.split(" ")

        # text.pop(0)
        # text.pop(0)
        text_list_1.append(text[0])
        tweet_id.append(text[1])
        # break

        # break
    # print(len(text_list_1))

    # text_list_1 = list(OrderedDict.fromkeys(text_list_1)) #np.unique(text_list_1,return_index=True)
    print(len(text_list_1))

    # for ele
    # for ele in text_list:
    # 	countX(text_list_1, ele)

    # text_list = list(text_list)
    text_list_1 = list(text_list_1)

    # dict_oc={}
    list_dic = []
    count = 1
    # file_wr = open('final1.txt','w')

    """COmpare same-----------"""
    # for ind, text in enumerate(text_list_1):
    #     try:
    #         if ind <= (len(text_list_1)-1):
    #             score=sim(text_list_1[ind], text_list_1[ind+1])
    #             if score>=0.90:
    #                 # count = 1
    #                 # list_dic.append([count, text])
    #                 text_list_1.remove(text_list_1[ind])
    #                 count += 1
    #                 print(text,score)
    #             else:
    #                 count =1
    #             list_dic.append([count, text_list_1[ind]])
            # count=0
                # print( count,"COUNT======================")

            # count=0
        # except Exception as e:
        #     print(e)
        #     pass
    list_product=[]
    # print(len(text_list_1), "len-----")
    # file_map = open("file_map.txt",'w')
    # file_map.write(" ".join(text_list_1))
    # file_map.close()
    # print(text_list_1[0])
    """ELEMent count"""
    # for ele in text_list:
    # 	occ=countX(text_list_1,ele)
        # print(occ,ele)

    count_query=0
    for ind, te in enumerate(text_list_1):
        te = te.lstrip()
        if te!="" : # and count_query<=5000:
            with open('Fake_scraped_2513.txt','a',encoding='utf-8') as file_json:
                dictionary_final =beaut_scrape(te,tweet_id[ind],count_query)
                # inter_product.append
                # print(tweet_id[ind],"----------tweet-----------")
                list_product.append(dictionary_final)
                # file_wr.write(te)
                # break
            # file_json = open('data_json.txt','w',encoding='utf-8')
            # print(list_product)
            # with open('data_json_!.txt','w',encoding='utf-8') as file_json:
                json.dump(list_product, file_json)
                count_query+=1
                list_product = []
    # json.dumps(list_product)
    # file_json.write({list_prduct})

    # file_json.close()
    # # file_wr.close()
    # print(len(text_list))
    # driver.quit()


"""SCRAPE USING BEAUTIFULSOUP"""
def beaut_scrape(query,tweet,ind):

    list_product = []
    # q='Brexit before:02-03-2018 after:02-02-2018'
    print(query, "----query", ind)
    query = query.replace(' ', '+')
    # q='Brexit before:02-03-2018 after:02-02-2018'
    res = requests.get('https://google.com/search?q={}'.format(query), timeout=10)
    # res = requests.get(url)
    html_page = res.content
    soup = BeautifulSoup(html_page, features="lxml")  # , 'html.parser')
    # print(soup.find_all('a').get('href'))
    # print(soup)
    text_a = soup.findAll("h3")
    # print(text_a[1].text, "----------", type(text_a), len(text_a))
    # te=text_a[0].replace('</div></h3>','')
    # print(te, "tetet")
    # text = soup.find_all(text=True)
    count=0
    links = soup.findAll("a")
    for ind, link in enumerate(links):
        link_href = link.get('href')
        # print(ind)
        if count<5:
            if link_href != None and count<len(text_a):
                if "url?q=" in link_href and not "webcache" in link_href:
                    try:
                        # print(link.get('href').split("?q=")[1].split("&sa=U")[0], "jijijiji", text_a[count].text)
                        URL_first=link.get('href').split("?q=")[1].split("&sa=U")[0]
                        text_in= text_a[count].text
                        res_u = requests.get(URL_first, timeout=10)
                        html_page = res_u.content
                        soup = BeautifulSoup(html_page, 'html.parser')
                        text = soup.find_all(text=True)
                        output = ''
                        new = ['p', 'li']
                        for t in text:
                            # print(t, "t")
                            if t.parent.name in new:
                                output += '{} '.format(t)
                        if text_in != "" and output != "":
                            count += 1
                            # print(output, "------OUTPUT-----------")
                            try:
                                product_data = {
                                    'title_' + str(count): text_in,
                                    'article_' + str(count): output,
                                    'source_url_' + str(count): URL_first}
                                # 'date_'+str(count): date }

                                list_product.append(product_data)
                                # count+=1

                            except Exception:
                                traceback.print_exc()
                    except Exception as e:
                        pass
                    count+=1
    query = query.replace('+', ' ')
    dict_fin = {'query': query, 'tweet_id':tweet,'top5': list_product}
    # driver.quit()
    # print(list_product)

    return dict_fin


"""SCRAPE USING SELENIUM"""

def scrape(query):
    print(query,"-query")
    query = query.replace(' ', '+')
    URL = f"http://www.google.com/search?q={query}"
    print(URL, "initital----------------")
    driver.get(URL)
    date_t=""
    date_t_2=""
    product_data_fn={}
    list_product=[]
    try:
        # title = driver.find_element_by_xpath('//h3')

        # tool_c = driver.find_element_by_xpath('//*[@id="hdtb-tls"]').click()


        # tool_da = driver.find_element_by_xpath('//*[@id="hdtbMenus"]/div/div[2]/div').click()
        # time.sleep(1)
        # driver.find_element_by_xpath('//*[@id="hdtb-tls"]').click()
        # time.sleep(1)
        # driver.find_element_by_xpath('//*[@id="hdtbMenus"]/div/div[2]').click()
        # time.sleep(1)
        # print("tool-11111111111111---")
        # test = driver.find_element_by_xpath('//*[@id="cdrlnk"]')
        # print(test.text,"------test text------")
        #
        # driver.find_element_by_xpath('//*[@id="cdrlnk"]').click()
        # print("-=========tool-11111111111111---")
        #
        # # Need to sort results date
        #
        # time.sleep(1)
        #
        # # // *[ @ id = "OouJcb"]
        #
        # date_F=driver.find_element_by_xpath('//*[@id="OouJcb"]') #[0].click()
        # print(date_F, "00i00i0")
        # date_F.send_keys("12 Sep 2020")
        #
        # date_rf = driver.find_element_by_xpath('//*[@id="rzG2be"]')  # [0].click()
        # print(date_rf, "00i00i0")
        # date_rf.send_keys("13 Sep 2020")
        #
        #
        # print("check time 01010101")
        # time.sleep(1)
        # driver.find_element_by_xpath('//*[@id="T3kYXe"]/g-button').click()
        # print("closing heree")
        #
        #
        #
        # print( "tool----")
        data_artice = driver.find_element_by_xpath('//*[@id="rso"]')
        print(data_artice.text, "itle0000")

        
        # list_text=data_artice.text.split("\n\n")
        linkList = []
        links = data_artice.find_elements_by_css_selector('a')
        list_text =  data_artice.find_elements_by_css_selector('h3')

        # for link in links:
        #     linkList.append(link.get_attribute('href'))

            # print()
        # print(linkList)
        # print("---------------------------------------------")
        count = 0
        for (text, link) in zip(list_text,links):
            text_in = text.text

            print(text_in,"0000000000000000000")
            # print("======================")
            # print(link.get_attribute('href'),"-dkalaskclakclkcackcldcdlnc")
            # break
            source_url = link.get_attribute('href')
            print(source_url,"=====11111111111111111source_url--------------")
            # print(source_url, "------------SOurc0911111110000000000000----------")
            # query_source =source_url.replace(' ', '+')
            URL_source = source_url #f"http://www.google.com/search?q={query_source}"
            # print(URL_source, "spurce url==================")
            # url = 'https://www.thehour.com/business/article/The-5-30-A-M-Warrior-Call-Could-We-Have-a-15221542.php'
            res = requests.get(URL_source)
            # print("kkkkkiii")
            html_page = res.content
            soup = BeautifulSoup(html_page, 'html.parser')
            links_first = soup.findAll("a")
            URL_first = ""
            # print(len(links_first),"lenght _======____")
            for link in links_first:
                    link_href = link.get('href')
                    # print("insidee=============")
                    if link_href != None:
                        if "url?q=" in link_href and not "webcache" in link_href:
                            URL_first = link.get('href').split("?q=")[1].split("&sa=U")[0]
                            print (link.get('href').split("?q=")[1].split("&sa=U")[0],"iniside urlssssssss")
                            break
            if URL_first =="":
                URL_first =URL_source
            # print("HI Trying=============")
            res = requests.get(URL_first)
            html_page = res.content
            soup = BeautifulSoup(html_page, 'html.parser')
            text = soup.find_all(text=True)
            output = ''
            new =['p','li']
            for t in text:
                # print(t, "t")
                if t.parent.name  in new:
                    output += '{} '.format(t)
                # print(t, "T")

            # print(output, "------OUTPUT-----------")

            # if len(text_in)>3:
            #     count +=1
            #     if text_in[0]=='Web results':
            #         text_in.pop(0)
            #     # print("insdie",text_in)
            #     title = text_in[0]
                 #text_in[1]
                # article= text_in[2]

                # print(title_source.text, "title_ soruce----------------")
                # driver.get(title_source)
                # /html/body/main/div[3]/div[2]/div/div[5]

                # /div[1]/div[2]/div/div[1]/div[1]/div[3]

                # matches =datefinder.find_dates(article)
                # date = ''
                # for i in matches:
                # 		date = str(i)
                # 		date = str(i)
                # 		break
            if text_in != "" and output != "":
                count += 1
                # print(output, "------OUTPUT-----------")
                try:
                    product_data = {
                        'title_'+str(count): text_in ,
                        'article_'+str(count): output,
                        'source_url_'+str(count): source_url}
                        # 'date_'+str(count): date }

                    list_product.append(product_data)
                    # count+=1

                except Exception:
                    traceback.print_exc()

            if count==6:
                break
            print(count, "count========================")
        query = query.replace('+', ' ')
        dict_fin={'query':query,'top5':list_product}
        # driver.quit()

        return dict_fin

    except Exception as e:
        print(e)
        pass



process(file_path)

# query='all of a sudden first and final year students have become immune to coronavirus medicoslivesmatter'
# scrape(query)